// pages/posts/posts.js
Page({

})