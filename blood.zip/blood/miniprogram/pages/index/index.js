//index.js
const app = getApp()

Page({
  onPullDownRefresh: function () {
    this.onLoad()
    wx.startPullDownRefresh()
    wx.stopPullDownRefresh()
  },
  viewTap(){
    wx.navigateTo({
     url: '/pages/posts/posts',
   })

  }


})

